/*
    * Vansh Juneja
    * DanceEmote.java
    * Ms.Krsateva
    * 2018-10-12
    * This program displays the dance emote of the MyCreation aniation
*/


// import statements
import java.awt.*; // colour libraries
import hsa.Console; // Console library
import java.lang.*; // Thread libraries

// MyCreation class
public class DanceEmote extends Thread
{
    private Console c; // new static Console c

    // happy emote method
    public void danceEmote ()
    {
	// colors
	Color bodyYellow = new Color (250, 200, 60);
	Color mouthPink = new Color (226, 133, 181);
	Color backBlue = new Color (200, 255, 255);

	// set starting relative y-value
	int y = 179;
	// delay
	try
	{
	    Thread.sleep(2000); // 2 second delay (2000ms)
	}
	catch (Exception e)
	{
	}
	for (int x = 0 ; x <= 150 ; x++)
	{
	    // erase
	    c.setColor (backBlue);
	    c.fillRect (2 + x, 18 + y, 99, 48);

	    // body fill
	    c.setColor (bodyYellow);
	    c.fillArc (30 + x, 18 + y, 12, 36, 90, 180); // left
	    c.fillArc (70 + x, 18 + y, 12, 36, 270, 180); // right
	    c.fillRect (36 + x, 18 + y, 40, 36);
	    // body outline
	    c.setColor (Color.black);
	    c.drawArc (30 + x, 18 + y, 12, 36, 90, 180); // left
	    c.drawArc (70 + x, 18 + y, 12, 36, 270, 180); // right
	    c.drawLine (36 + x, 18 + y, 76 + x, 18 + y); // top
	    c.drawLine (36 + x, 54 + y, 76 + x, 54 + y); // bottom
	    // eye lines
	    c.drawLine (36 + x, 30 + y, 42 + x, 24 + y); // left left
	    c.drawLine (42 + x, 24 + y, 48 + x, 30 + y); // left right
	    c.drawLine (60 + x, 30 + y, 66 + x, 24 + y); // right left
	    c.drawLine (66 + x, 24 + y, 72 + x, 30 + y); // right right
	    // mouth fill
	    c.setColor (mouthPink);
	    c.fillOval (48 + x, 38 + y, 12, 12);
	    // mouth outline
	    c.setColor (Color.black);
	    c.drawOval (48 + x, 38 + y, 12, 12);
	    // moustache lines
	    c.drawLine (50 + x, 33 + y, 50 + x, 35 + y);
	    c.drawLine (52 + x, 33 + y, 52 + x, 35 + y);
	    c.drawLine (54 + x, 33 + y, 54 + x, 35 + y);
	    c.drawLine (56 + x, 33 + y, 56 + x, 35 + y);
	    c.drawLine (58 + x, 33 + y, 58 + x, 35 + y);
	    // leg lines
	    c.drawLine (46 + x, 54 + y, 43 + x, 60 + y);
	    c.drawLine (69 + x, 54 + y, 72 + x, 60 + y);
	    // shoe fills
	    c.fillOval (36 + x, 60 + y, 8, 6);
	    c.fillOval (71 + x, 60 + y, 8, 6);
	    // left arm
	    c.drawLine (24 + x, 42 + y, 15 + x, 18 + y);
	    c.drawLine (15 + x, 18 + y, 6 + x, 36 + y);
	    // right arm
	    c.drawArc (68 + x, 6 + y, 30, 34, 280, 75);
	    // hand fills
	    c.setColor (bodyYellow);
	    c.fillOval (3 + x, 36 + y, 5, 5); // left
	    c.fillOval (95 + x, 19 + y, 5, 5); // right
	    // hand fills
	    c.setColor (Color.black);
	    c.drawOval (3 + x, 36 + y, 5, 5); // left
	    c.drawOval (95 + x, 19 + y, 5, 5); // right

	    // delay
	    try
	    {
		Thread.sleep (15);
	    }
	    catch (Exception e)
	    {
	    }
	}
    }


    // class constructor method
    public DanceEmote (Console con)
    {
	c = con; // private Console c is set as passsed Console arguement con
    }


    // Thread run method
    public void run ()
    {
	danceEmote (); // execute danceEmote method
    }
}
