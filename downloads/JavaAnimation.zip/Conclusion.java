/*
    * Vansh Juneja
    * Conclusion.java
    * Ms.Krsateva
    * 2018-10-12
    * This program displays the conclusion / final scene of the MyCreation aniation
*/


// import statements
import java.awt.*; // colour libraries
import hsa.Console; // Console library
import java.lang.*; // Thread libraries

// MyCreation class
public class Conclusion extends Thread
{
    private Console c; // new static Console c

    // conclusion method
    public void conclusion ()
    {
	// colors
	Color backBlue = new Color (0, 0, 255);

	// back
	c.setColor (backBlue);
	for (int i = 0 ; i <= 500 ; i++)
	{
	    c.drawLine (0, i, 640, i);
	}

	// text
	c.setColor (Color.white);
	c.setFont (new Font ("Artegra Slab Thin", 1, 15));
	c.drawString ("A problem has been detected and Windows has been shutdown to prevent damage", 5, 75);
	c.drawString ("to your computer", 5, 100);
	c.drawString ("By: Vansh J.", 5, 480);
    }


    // class constructor method
    public Conclusion (Console con)
    {
	c = con; // private Console c is set as passsed Console arguement con
    }


    // Thread run method
    public void run ()
    {
	conclusion (); // execute conclusion method
    }
}
