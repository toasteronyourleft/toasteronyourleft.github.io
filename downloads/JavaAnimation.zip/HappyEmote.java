/*
    * Vansh Juneja
    * HappyEmote.java
    * Ms.Krsateva
    * 2018-10-12
    * This program displays the happy emote of the MyCreation animation
*/


// import statements
import java.awt.*; // colour libraries
import hsa.Console; // Console library
import java.lang.*; // Thread libraries

// MyCreation class
public class HappyEmote extends Thread
{
    private Console c; // new static Console c

    // happy emote method
    public void happyEmote ()
    {
	// colors
	Color hairBlue = new Color (120, 230, 200);
	Color bodyYellow = new Color (255, 225, 40);
	Color mouthPink = new Color (226, 133, 181);
	Color noseRed = new Color (230, 100, 70);
	Color backBlue = new Color (200, 255, 255);

	// variables
	int y = 179; // set starting relative y-value

	for (int x = -5 ; x <= 300 ; x++)
	{
	    // erase
	    c.setColor (backBlue);
	    c.fillRect (8 + x, 6 + y, 95, 61);

	    // hair fill
	    c.setColor (hairBlue);
	    c.fillOval (36 + x, 6 + y, 12, 12);
	    c.fillOval (48 + x, 7 + y, 13, 12);
	    c.fillOval (61 + x, 7 + y, 12, 12);
	    c.fillOval (72 + x, 11 + y, 8, 8);
	    // hair outline
	    c.setColor (Color.black);
	    c.drawOval (36 + x, 6 + y, 12, 12);
	    c.drawOval (48 + x, 7 + y, 13, 12);
	    c.drawOval (61 + x, 7 + y, 12, 12);
	    c.drawOval (72 + x, 11 + y, 8, 8);
	    // body fill
	    c.setColor (bodyYellow);
	    c.fillRoundRect (30 + x, 18 + y, 50, 42, 28, 28);
	    // body outline
	    c.setColor (Color.black);
	    c.drawRoundRect (30 + x, 18 + y, 50, 42, 28, 28);
	    // legs
	    c.drawLine (44 + x, 60 + y, 42 + x, 66 + y); // left
	    c.drawLine (69 + x, 60 + y, 71 + x, 66 + y); // right
	    // shoes fill
	    int leftShoeX[] = {34 + x, 34 + x, 43 + x, 42 + x};
	    int leftShoeY[] = {67 + y, 64 + y, 63 + y, 67 + y};
	    int rightShoeX[] = {79 + x, 79 + x, 70 + x, 72 + x};
	    int rightShoeY[] = {67 + y, 64 + y, 63 + y, 67 + y};
	    c.fillPolygon (leftShoeX, leftShoeY, 4); // left
	    c.fillPolygon (rightShoeX, rightShoeY, 4); // right
	    c.fillPolygon (leftShoeX, leftShoeY, 4); // left
	    c.fillPolygon (rightShoeX, rightShoeY, 4); // right
	    // arms
	    c.drawLine (27 + x, 35 + y, 14 + x, 23 + y); // left
	    c.drawLine (83 + x, 41 + y, 96 + x, 55 + y); // right
	    // hands fills
	    c.setColor (bodyYellow);
	    c.fillOval (9 + x, 18 + y, 5, 5); // left
	    c.fillOval (96 + x, 55 + y, 5, 5); // right
	    // hands outlines
	    c.setColor (Color.black);
	    c.drawOval (9 + x, 18 + y, 5, 5); // left
	    c.drawOval (96 + x, 55 + y, 5, 5); // right
	    // eye serifs
	    c.setColor (Color.black);
	    c.drawLine (34 + x, 30 + y, 38 + x, 30 + y); // left left
	    c.drawLine (46 + x, 30 + y, 50 + x, 30 + y); // left right
	    c.drawLine (58 + x, 30 + y, 62 + x, 30 + y); // right left
	    c.drawLine (69 + x, 30 + y, 73 + x, 30 + y); // right right
	    // eye lines
	    c.drawLine (36 + x, 30 + y, 42 + x, 24 + y); // left left
	    c.drawLine (42 + x, 24 + y, 48 + x, 30 + y); // left right
	    c.drawLine (60 + x, 30 + y, 66 + x, 24 + y); // right left
	    c.drawLine (66 + x, 24 + y, 72 + x, 30 + y); // right right
	    // blush lines
	    c.drawLine (35 + x, 36 + y, 38 + x, 33 + y); // left left
	    c.drawLine (40 + x, 36 + y, 43 + x, 33 + y); // left middle
	    c.drawLine (45 + x, 36 + y, 48 + x, 33 + y); // left right
	    c.drawLine (60 + x, 36 + y, 63 + x, 33 + y); // right left
	    c.drawLine (65 + x, 36 + y, 68 + x, 33 + y); // right middle
	    c.drawLine (70 + x, 36 + y, 73 + x, 33 + y); // right right
	    // nose fills
	    c.setColor (noseRed);
	    c.fillOval (52 + x, 36 + y, 4, 4);
	    // nose outlines
	    c.setColor (Color.black);
	    c.drawOval (52 + x, 36 + y, 4, 4);
	    // mouth fills
	    int mouthX[] = {48 + x, 54 + x, 60 + x};
	    int mouthY[] = {45 + y, 54 + y, 45 + y};
	    c.setColor (mouthPink);
	    c.fillPolygon (mouthX, mouthY, 3);
	    // mouth outlines
	    c.setColor (Color.black);
	    c.drawPolygon (mouthX, mouthY, 3);

	    // delay
	    try
	    {
		Thread.sleep (10); // 10ms delay between frames of animation
	    }
	    catch (Exception e)
	    {
	    }
	}
    }


    // class constructor method
    public HappyEmote (Console con)
    {
	c = con; // private Console c is set as passsed Console arguement con
    }


    // Thread run method
    public void run ()
    {
	happyEmote (); // execute happyEmote method
    }
}

